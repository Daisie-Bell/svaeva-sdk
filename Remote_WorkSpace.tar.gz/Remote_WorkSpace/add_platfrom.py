from svaeva import Panel
from dotenv import load_dotenv
import os
load_dotenv()
panel = Panel(os.getenv("PANEL_URL"), os.getenv("PANEL_TOKEN"))

panel.platform.cli = {"pf_prams":["username"]}