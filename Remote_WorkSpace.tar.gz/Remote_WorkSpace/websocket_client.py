import asyncio
import websockets
from svaeva import Panel


async def websocket_client():
    uri = "ws://192.168.1.205:8000/v1/multiapi/ola/stream?token={}"
    token = input("Enter your token: ")
    panel = Panel("http://192.168.1.205:8000",token)
    while True:
        r_l = input("you are a new user? (y/n): ")
        if r_l == "y":
            user_name = input("Enter your name: ")
            panel.user.__setattr__(user_name,{"platform":"cli"})
            break
        elif r_l == "n":
            user_name = input("Enter your name: ")
            panel.user(platform="cli",arg=user_name)
            break
    async with websockets.connect(uri.format(token)) as websocket:
        response = await websocket.recv()
        print(f"{response}")
        while True:
            message_to_send = input("User: ")
            message = {
                "sender" : "",
                "type" : "text",
                "text" : message_to_send,

            }
            await websocket.send(message_to_send)
            for _ in range(2):
                response = await websocket.recv()
                print(f"Received from server: {response}")
asyncio.get_event_loop().run_until_complete(websocket_client())