from svaeva import Panel

from dotenv import load_dotenv

import os

load_dotenv()

panel = Panel(os.getenv("PANEL_URL"), os.getenv("PANEL_TOKEN"))

print("Adding keys")
print(panel.wallet())

panel.wallet.add_key("open_ai","sk-{}".format(os.getenv("OPENAI_KEY")))
panel.wallet.add_key("deepgram","{}".format(os.getenv("DEEPGRAM_KEY")))
panel.wallet.add_key("elevanlabs","{}".format(os.getenv("ELEVANLABS_KEY")))