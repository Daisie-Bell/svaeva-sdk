from svaeva import Panel

from dotenv import load_dotenv

import os

load_dotenv()

panel = Panel(os.getenv("PANEL_URL"), os.getenv("PANEL_TOKEN"))

skeletons = {
    "deepgram" : {
        "type_model": "speech-to-text",
        "end_point" : "https://api.deepgram.com/v1/",
        "header"    : {
            "accept": "application/json",
            "content-type": "application/json",
            "*Authorization": "Token {}"
        },
        "skeleton"  : {
            "pre_recode" : {
                "suffix" : "listen",
                "method" : "POST"
            },
            "stream" : {
                "suffix" : "listen",
                "method" : "ws"
            }
        }
    },
    "openai": {
        "type_model": "llm",
        "end_point": "https://api.openai.com/v1/",
        "header": {
            "accept": "application/json",
            "content-type": "application/json",
            "*Authorization": "Bearer {}"
        },
        "skeleton": {
            "complete": {
                "suffix": "chat/completions",
                "method": "POST"
            }
        }
    },
    "elevanlabs": {
        "type_model": "text-to-speech",
        "end_point": "https://api.elevenlabs.io/v1/",
        "header":{
            "Accept": "audio/mpeg",
            "Content-Type": "application/json",
            "*xi-api-key": "{}"
        },
        "skeleton" : {
            "text_to_speech": {
                "suffix": "text-to-speech/nTXOAnuxZbBqWJ62qizX",
                "method": "POST"
            }
        }
    }
}

for i in skeletons:
    panel.skeleton.__setattr__(i,skeletons[i])