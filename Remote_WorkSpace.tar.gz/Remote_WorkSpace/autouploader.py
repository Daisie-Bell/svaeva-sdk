import time
from svaeva import Panel

import os

from dotenv import load_dotenv

from pathlib import Path

load_dotenv()

working_dir = Path("./Vortex")

panel = Panel(os.getenv("PANEL_URL"), os.getenv("PANEL_TOKEN"))

if not working_dir.exists():
    working_dir.mkdir()
try:
    for_all = panel.virtual()

    print(for_all)
    if isinstance(for_all,dict):
        for_all = [for_all]
    for i in for_all:
        print(f"Downloading {i['id']}")
        open(working_dir / f"{i['id']}.py","w").write(i["row_code"])
except Exception as e:
    print(e)

while True:
    for _ in working_dir.iterdir():
        if _.suffix == ".py":
            name = _.name.split(".")[0]
            try:
                if panel.virtual(id=name) is None:
                    print(f"Creating {name}")
                    panel.virtual.__setattr__(name,{
                        "model_type" : "test",
                        "row_code" : open(_,"r").read()
                    })
                else:
                    uplaod = open(_,"r").read()
                    remote = panel.virtual(id=name)
                    if remote["status"] == "error" or remote["status"] == "run-error":
                        print(remote["error"])
                    if remote["row_code"] == uplaod:
                        continue
                    else:
                        print(f"Uploading {name}")
                        panel.virtual.update(name,{
                            "row_code" : uplaod,
                            "status"   : "pending",
                            "error"    : None
                        })
                        time.sleep(15)
                        info = panel.virtual(id=name)
                        if info["row_code"] != uplaod:
                            open(_,"w").write(info["row_code"])
                        if info["status"] == "error":
                            print(info["error"])
            except Exception as e:
                try:
                    print(e)
                    uplaod = open(_,"r").read()
                    print(f"Creation {name}")
                    panel.virtual.__setattr__(name,{
                        "model_type" : "VortexColetion",
                        "row_code" : uplaod,
                        "status"   : "pending",
                        "error"    : None
                    })
                    time.sleep(15)
                    info = panel.virtual(id=name)
                    if info["row_code"] != uplaod:
                        open(_,"w").write(info["row_code"])
                    if info["status"] == "error":
                        print(info["error"])
                except Exception as e:
                    print(e)
            time.sleep(30)