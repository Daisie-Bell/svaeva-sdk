#test
from typing import Any


class test:
    def __init__(self,token) -> None:
       pass

    def __call__(self,data : Any) -> Any:
        if data["type"] == "websocket.receive":
            data = data["text"]
            return data
        pass
