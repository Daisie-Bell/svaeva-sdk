

import os

from dotenv import load_dotenv
from svaeva import Panel

load_dotenv()

panel = Panel(os.getenv("PANEL_URL"), os.getenv("PANEL_TOKEN"))


deepgram_auto = {
    "smart_format": "true",
    "detect_language": "true",
    "model": "nova-2"
}

config_svaeva = {
    "api_id":"deepgram",
    "function_name":"pre_recode",
    "config":deepgram_auto
}

panel.config.__setattr__("auto_deep",config_svaeva)